@ECHO OFF

"%~dp0Image Aspect Ratio Grouper.CLI.exe" /?

PAUSE